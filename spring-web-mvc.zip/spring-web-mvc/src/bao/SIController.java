package bao;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.SI;

@Controller
public class SIController {
@RequestMapping("siload")
public String siLoad(Model mp)  // passing data as a model attribute
{
	SI obj = new SI();
	mp.addAttribute("siform",obj);
	return "siview";
}
@RequestMapping("sicode")
public ModelAndView siCode(@ModelAttribute("siform")SI s)
{
	float si = (s.getP() * s.getR()* s.getT())/100;
	//ModelAndView obj = new ModelAndView("siview","command",new SI());
	//obj.addObject("key","result is "+si);
	//return obj;
	return new ModelAndView("siview","command",
			new SI()).addObject("key","result is "+si + "basic is "+s.getBasic() + "advance is "+s.getAdvance());
	//return new ModelAndView("sires","key","result is "+si);
}
}
