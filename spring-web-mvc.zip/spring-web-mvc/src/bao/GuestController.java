package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class GuestController {
	@RequestMapping("home")
    public String homePage()
    {
    	return "home";
    }
	@RequestMapping("about")
	public String aboutPage()
    {
    	return "about";
    }
	@RequestMapping("contact")
	public String contactPage()
    {
    	return "contact";
    }
	@RequestMapping("services")
	public String servicesPage()
    {
    	return "services";
    }
	@RequestMapping("gallery")
	public String galleryPage()
    {
    	return "gallery";
    }
}
