package bao;

import org.hibernate.Query;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.*;
import helper.HiberHelper;
@Controller
public class StudentController {
	HiberHelper db = new HiberHelper();
   @RequestMapping("stuload")
   public ModelAndView stuLoad()
   {
	   db.hiberConfigure();
	   List lst = db.getData("from Student s");
	   ModelAndView mo = new ModelAndView("stuview","command",new Stu());
	   mo.addObject("key1",lst);
	   return mo;
   }
   @RequestMapping("stucode")
   public ModelAndView stuCode(@ModelAttribute("xyz")Stu obj,HttpServletRequest req)
   {
	   db.hiberConfigure();
	   Student st = new Student();
	   st.setRno(obj.getRno());
	   st.setSname(obj.getSname());
	   if(req.getParameter("btnsubmit").equals("Update"))
	   {
		 db.updateData(st);
	   }
	   else
	   {
	   
	   db.insertData(st);
	   }
	   List lst = db.getData("from Student s");
	   ModelAndView mo = new ModelAndView("stuview","command",new Student());
	   mo.addObject("key1",lst);
	   mo.addObject("key", "Operation Success");
	   
	   return mo;
   }
   @RequestMapping("viewstu")
   public ModelAndView viewstu()
   {
	  db.hiberConfigure();
	   List lst = db.getData("from Student s");
	   return new ModelAndView("stuview","command",new Student()).addObject("key1",lst);
   }
   @RequestMapping("editstu")
   public ModelAndView editstu(HttpServletRequest request)
   {
	   db.hiberConfigure();
	   Student o =(Student) db.findData(Student.class,Integer.parseInt(request.getParameter("q")));
	   List lst = db.getData("from Student s");
	   ModelAndView mo = new ModelAndView("stuview","command",o);
	   mo.addObject("key1",lst);
	   mo.addObject("btnkey","update");
	   return mo;
   }
   @RequestMapping("deletestu")
   public ModelAndView deletestu(HttpServletRequest request)
   {
	   db.hiberConfigure();
	   db.deleteData(Student.class,Integer.parseInt(request.getParameter("q")));
	   return new ModelAndView("redirect:stuload.html");
   }
}
