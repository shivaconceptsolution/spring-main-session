
public class Stu {

}
